#!/usr/bin/env python3
import requests
import time
from datetime import datetime

URL = "https://yandex.com/time/sync.json?geo=213"

def get_time():
    try:
        response = requests.get(URL)
        response.raise_for_status()
    except Exception as err:
        print(f"Ошибка запроса: {err}")
        return None

    try:
        data = response.json()
        return data.get("time"), data.get("timezone", "Unknown")
    except Exception as err:
        print(f"Ошибка обработки JSON: {err}")
        return None

if __name__ == "__main__":
    deltas = []
    for _ in range(5):
        start = time.time()
        result = get_time()
        if result is None:
            continue

        api_time, tz = result
        formatted_time = datetime.fromtimestamp(api_time).strftime("%Y-%m-%d %H:%M:%S")
        delta = api_time - start

        print(f"API время: {formatted_time}, Временная зона: {tz}, Разница: {delta:.3f} сек\n")
        deltas.append(delta)
        time.sleep(1)

    if deltas:
        print(f"Средняя разница времени: {sum(deltas) / len(deltas):.3f} сек")
    else:
        print("Не удалось получить корректные данные.")
