#!/usr/bin/env python3
import os
import sys
import json
import shutil
import subprocess
import tempfile
from datetime import datetime
from zipfile import ZipFile

def log(msg):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}")

def clone_repo(repo_url, repo_dir):
    log(f"Клонируем {repo_url}...")
    result = subprocess.run(["git", "clone", repo_url, repo_dir], capture_output=True, text=True)
    if result.returncode != 0:
        log(f"Ошибка клонирования: {result.stderr.strip()}")
        sys.exit(1)

def copy_code(src, dst):
    if os.path.exists(dst):
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    log(f"Код скопирован в {dst}")

def create_version_file(directory, version):
    files = [f for f in os.listdir(directory) if f.endswith(('.py', '.js', '.sh'))]
    version_data = {"version": version, "files": files}
    with open(os.path.join(directory, "version.json"), "w") as f:
        json.dump(version_data, f, indent=4)
    log("Файл version.json создан.")

def create_zip(src_dir):
    archive_name = f"{os.path.basename(src_dir)}_{datetime.now().strftime('%d%m%Y')}.zip"
    log(f"Архивируем в {archive_name}...")
    with ZipFile(archive_name, 'w') as zipf:
        for root, _, files in os.walk(src_dir):
            for file in files:
                zipf.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), os.path.dirname(src_dir)))
    log("Архивация завершена.")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Использование: task2.py <repo_url> <source_path> <version>")
        sys.exit(1)

    repo_url, source_path, version = sys.argv[1:4]

    with tempfile.TemporaryDirectory() as tmpdir:
        repo_dir = os.path.join(tmpdir, "repo")
        clone_repo(repo_url, repo_dir)
        full_src_path = os.path.join(repo_dir, source_path)

        if not os.path.exists(full_src_path):
            log(f"Ошибка: {full_src_path} не найден")
            sys.exit(1)

        project_dir = os.path.join(os.getcwd(), os.path.basename(source_path))
        copy_code(full_src_path, project_dir)
    
    create_version_file(project_dir, version)
    create_zip(project_dir)
