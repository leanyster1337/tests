#!/usr/bin/env python3
import sys
import json

def parse_version(ver):
    return tuple(map(int, ver.split('.')))

def expand_versions(pattern):
    parts = pattern.split('.')
    versions = []

    def recursive_build(index, current):
        if index == len(parts):
            versions.append(".".join(current))
            return
        if parts[index] == "*":
            for num in ["7", "3"]:
                recursive_build(index + 1, current + [num])
        else:
            recursive_build(index + 1, current + [parts[index]])

    recursive_build(0, [])
    return versions

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Использование: task3.py <product_version> <config_file>")
        sys.exit(1)

    product_version = sys.argv[1]
    config_file = sys.argv[2]

    try:
        with open(config_file) as cf:
            config = json.load(cf)
    except Exception as e:
        print(f"Ошибка чтения {config_file}: {e}")
        sys.exit(1)

    all_versions = []
    for pattern in config.values():
        all_versions.extend(expand_versions(pattern))

    all_versions.sort(key=parse_version)
    
    print("\nСписок версий:")
    print("\n".join(all_versions))

    product_ver_tuple = parse_version(product_version)
    older_versions = [v for v in all_versions if parse_version(v) < product_ver_tuple]

    print(f"\nВерсии старше {product_version}:")
    print("\n".join(older_versions))
