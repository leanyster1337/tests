#!/bin/bash
set -e

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

units=$(systemctl list-units --type=service --all --no-legend "foobar-*.service" | awk '{print $1}')

if [ -z "$units" ]; then
    log "Нет сервисов foobar-*."
    exit 0
fi

for unit in $units; do
    log "Обновляем $unit..."

    sudo systemctl stop "$unit"

    unit_file=$(systemctl show -p FragmentPath "$unit" | cut -d'=' -f2)
    if [ ! -f "$unit_file" ]; then
        log "Файл $unit_file не найден, пропускаем."
        continue
    fi

    working_dir=$(grep "^WorkingDirectory=" "$unit_file" | cut -d'=' -f2)
    service_name=$(basename "$working_dir")

    src_dir="/opt/misc/$service_name"
    dest_dir="/srv/data/$service_name"

    if [ ! -d "$src_dir" ]; then
        log "Исходная директория $src_dir отсутствует, пропускаем."
        continue
    fi

    sudo mkdir -p "$dest_dir"
    sudo mv "$src_dir"/* "$dest_dir"/
    sudo sed -i "s|$src_dir|$dest_dir|g" "$unit_file"
    sudo systemctl daemon-reload
    sudo systemctl start "$unit"

    log "$unit обновлён."
done
